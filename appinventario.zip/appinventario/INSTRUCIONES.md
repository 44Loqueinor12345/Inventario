

**Migrar inventario**

pg\_dump -U postgres -h localhost -p 5432 inventario > inventario.sql

psql -U postgres -h localhost -p 5432 -d inventario\_utf8 -f inventario.sql





**ACTUALIZAR BASE** 

Cada que se quiera actualizar la base de datos agregando un nuevo campo en model.py



python -m flask db migrate -m "Plantilla actualizacion"

python -m flask db upgrade









**Entrar a la base por el cmd** 

psql -U inventario\_user -h localhost -p 5432 -d inventario\_utf8  pss: Inventario 2025

psql -U postgres -h localhost -p 5432 -d inventario\_utf8         pss:Calsetin123







**Reiniciar el servicio cuando se altere el codigo(ya que la ap esta como servicio windows, powershell en administrador )**

PS C:\\nssm> Restart-Service InventarioSer





