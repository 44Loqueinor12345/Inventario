import os, io, uuid, barcode
import pandas as pd
from datetime import datetime
from flask import Flask, render_template, request, jsonify, send_file, redirect, url_for, flash
from werkzeug.utils import secure_filename
from barcode.writer import ImageWriter
from flask_migrate import Migrate
from models import db, Grupo, CodigoBarra, Dispositivo, ProductoVenta, MaterialGeneral, Plantilla


app = Flask(__name__)
app.secret_key = "Calsetin123"  # Necesario para usar flash messages

# Configuración de BD PostgreSQL
app.config["SQLALCHEMY_DATABASE_URI"] = "postgresql://inventario_user:Inventario2025!@localhost/inventario_utf8"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['BARCODE_FOLDER'] = 'static/barcodes'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['BARCODE_FOLDER'], exist_ok=True)

db.init_app(app)
migrate = Migrate(app, db)

# -------------------
# Utilidades
# -------------------
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def generar_codigo_barras():
    while True:
        codigo = str(int(datetime.now().timestamp() * 1000))[-12:]
        if not CodigoBarra.query.filter_by(codigo=codigo).first():
            return codigo

def generar_imagen_codigo_barras(codigo):
    try:
        code128 = barcode.get_barcode_class("code128")
        barcode_instance = code128(codigo, writer=ImageWriter())
        filename = f"{codigo}"
        filepath = os.path.join(app.config["BARCODE_FOLDER"], filename)
        barcode_instance.save(filepath)
        return f"/{filepath}.png"
    except Exception as e:
        print("Error generando código de barras:", e)
        return ""

# -------------------
# Rutas
# -------------------
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/inventario_general')
def inventario_general():
    grupos = Grupo.query.all()
    return render_template('inventario_general.html', grupos=[{"id": g.id, "nombre": g.nombre, "descripcion": g.descripcion} for g in grupos])

@app.route('/inventario_grupo/<grupo_nombre>')
def inventario_grupo(grupo_nombre):
    grupo = Grupo.query.filter_by(nombre=grupo_nombre).first()
    if not grupo:
        return "Grupo no encontrado", 404
    dispositivos = Dispositivo.query.filter_by(grupo_id=grupo.id).all()
    productos = ProductoVenta.query.filter_by(grupo_id=grupo.id).all()
    materiales = MaterialGeneral.query.filter_by(grupo_id=grupo.id).all()
    return render_template('inventario_grupo.html', grupo=grupo, dispositivos=dispositivos, productos_venta=productos, material_general=materiales)

@app.route('/agregar_producto', methods=['GET', 'POST'])
def agregar_producto():
    grupos = Grupo.query.all()

    if request.method == 'POST':
        tipo = request.form['tipo']
        grupo_id = request.form.get('grupo_id')
        cantidad = int(request.form.get('cantidad', 1))  # 🔹 Ahora cantidad vive solo aquí
        plantilla_id = request.form.get('plantilla')

        # Si no hay grupo, usar ALMACEN
        if not grupo_id or grupo_id.strip() == "":
            grupo_default = Grupo.query.filter_by(nombre="ALMACEN").first()
            grupo_id = grupo_default.id if grupo_default else None

        # Si hay plantilla, traerla
        plantilla_data = None
        if plantilla_id:
            plantilla = Plantilla.query.get(plantilla_id)
            if plantilla:
                plantilla_data = plantilla.__dict__

        productos_creados = []
        foto_url = ""

        # 🔹 Bucle dentro del POST
        for _ in range(cantidad):
            codigo_barras = generar_codigo_barras()

            # Guardar foto solo en dispositivos
            if tipo == "dispositivo" and "foto" in request.files:
                file = request.files["foto"]
                if file and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    unique_filename = f"{uuid.uuid4().hex}_{filename}"
                    file_path = os.path.join(app.config["UPLOAD_FOLDER"], unique_filename)
                    file.save(file_path)
                    foto_url = f"/static/uploads/{unique_filename}"

            # Crear registro según tipo
            if tipo == "dispositivo":
                nuevo = Dispositivo(
                    grupo_id=grupo_id,
                    responsable=request.form.get("responsable") or (plantilla_data.get("responsable_p") if plantilla_data else ""),
                    marca=request.form.get("marca") or (plantilla_data.get("marca_p") if plantilla_data else ""),
                    modelo=request.form.get("modelo") or (plantilla_data.get("modelo_p") if plantilla_data else ""),
                    numserie=request.form.get("numserie") or "",
                    vpn=request.form.get("vpn") or (plantilla_data.get("vpn_p") if plantilla_data else ""),
                    canal_vpn=request.form.get("canal_vpn") or (plantilla_data.get("canal_vpn_p") if plantilla_data else ""),
                    room=request.form.get("room") or (plantilla_data.get("room_p") if plantilla_data else ""),
                    cuentas_tiktok=request.form.get("cuentas_tiktok") or (plantilla_data.get("cuentas_tiktok_p") if plantilla_data else ""),
                    pais=request.form.get("pais") or (plantilla_data.get("pais_p") if plantilla_data else ""),
                    apple_id=request.form.get("apple_id") or (plantilla_data.get("apple_id_p") if plantilla_data else ""),
                    foto=foto_url,
                    costo=float(request.form.get("costo") or (plantilla_data.get("costo_p") if plantilla_data else 0)),
                    comentarios=request.form.get("comentarios") or (plantilla_data.get("comentarios_p") if plantilla_data else ""),
                    codigo_barras=codigo_barras
                )
                db.session.add(nuevo)

            elif tipo == "producto_venta":
                nuevo = ProductoVenta(
                    grupo_id=grupo_id,
                    marca=request.form.get("marca_venta") or (plantilla_data.get("marca_venta_p") if plantilla_data else ""),
                    descripcion=request.form.get("descripcion_venta") or (plantilla_data.get("descripcion_venta_p") if plantilla_data else ""),
                    caducidad=request.form.get("caducidad_venta") or (plantilla_data.get("caducidad_venta_p") if plantilla_data else None),
                    costo=float(request.form.get("costo_venta") or (plantilla_data.get("costo_venta_p") if plantilla_data else 0)),
                    lote=request.form.get("lote_venta") or (plantilla_data.get("lote_venta_p") if plantilla_data else ""),
                    codigo_barras=codigo_barras
                )
                db.session.add(nuevo)

            elif tipo == "material_general":
                nuevo = MaterialGeneral(
                    nombre=request.form.get("nombre_material") or (plantilla_data.get("nombre_material_p") if plantilla_data else ""),
                    tipo=request.form.get("tipo_material") or (plantilla_data.get("tipo_material_p") if plantilla_data else ""),
                    modelo=request.form.get("modelo_material") or (plantilla_data.get("modelo_material_p") if plantilla_data else ""),
                    responsable=request.form.get("responsable_material") or (plantilla_data.get("responsable_material_p") if plantilla_data else ""),
                    grupo_id=grupo_id,
                    room=request.form.get("room_material") or (plantilla_data.get("room_material_p") if plantilla_data else ""),
                    precio=float(request.form.get("precio_material") or (plantilla_data.get("precio_material_p") if plantilla_data else 0)),
                    codigo_barras=codigo_barras
                )
                db.session.add(nuevo)

            # Guardar código en su tabla
            #db.session.add(CodigoBarra(codigo=codigo_barras))
            productos_creados.append(codigo_barras)

        db.session.commit()

        barcodes_paths = [generar_imagen_codigo_barras(cb) for cb in productos_creados]

        return jsonify({
            "success": True,
            "message": f"{len(productos_creados)} producto(s) agregado(s) correctamente",
            "codigos_barras": productos_creados,
            "barcodes_images": barcodes_paths,
            "foto_url": foto_url
        })

    # GET → mostrar formulario
    return render_template("agregar_producto.html", grupos=grupos)



@app.route("/plantillas")
def listar_plantillas():
    plantillas = Plantilla.query.all()
    return render_template("plantillas.html", plantillas=plantillas)



from datetime import datetime

# Crear o editar plantilla
@app.route("/plantillas/nueva", methods=["GET", "POST"])
def nueva_plantilla():
    plantilla_id = request.args.get("id")
    plantilla = None

    if plantilla_id:
        plantilla = Plantilla.query.get(plantilla_id)

    if request.method == "POST":

        # --- Normalización de valores ---
        def parse_float(value):
            return float(value) if value not in (None, "", " ") else None

        def parse_date(value):
            return datetime.strptime(value, "%Y-%m-%d").date() if value not in (None, "", " ") else None

        if request.form.get("id"):  
            # EDITAR
            plantilla = Plantilla.query.get(request.form["id"])
            plantilla.nombre_p = request.form["nombre_p"]
            plantilla.tipo_p = request.form["tipo_p"]

            # Dispositivo
            plantilla.responsable_p = request.form.get("responsable_p")
            plantilla.marca_p = request.form.get("marca_p")
            plantilla.modelo_p = request.form.get("modelo_p")
            plantilla.numserie_p = request.form.get("numserie_p")
            plantilla.cuentas_tiktok_p = request.form.get("cuentas_tiktok_p")
            plantilla.apple_id_p = request.form.get("apple_id_p")


            plantilla.vpn_p = request.form.get("vpn_p")
            plantilla.canal_vpn_p = request.form.get("canal_vpn_p")
            plantilla.room_p = request.form.get("room_p")
            plantilla.pais_p = request.form.get("pais_p")
            plantilla.costo_p = parse_float(request.form.get("costo_p"))
            plantilla.comentarios_p = request.form.get("comentarios_p")

            # Producto de venta
            plantilla.marca_venta_p = request.form.get("marca_venta_p")
            plantilla.descripcion_venta_p = request.form.get("descripcion_venta_p")
            plantilla.caducidad_venta_p = parse_date(request.form.get("caducidad_venta_p"))
            plantilla.costo_venta_p = parse_float(request.form.get("costo_venta_p"))
            plantilla.lote_venta_p = request.form.get("lote_venta_p")

            # Material general
            plantilla.nombre_material_p = request.form.get("nombre_material_p")
            plantilla.tipo_material_p = request.form.get("tipo_material_p")
            plantilla.modelo_material_p = request.form.get("modelo_material_p")
            plantilla.responsable_material_p = request.form.get("responsable_material_p")
            plantilla.room_material_p = request.form.get("room_material_p")
            plantilla.precio_material_p = parse_float(request.form.get("precio_material_p"))

        else:
            # CREAR
            plantilla = Plantilla(
                nombre_p=request.form["nombre_p"],
                tipo_p=request.form["tipo_p"],

                # Dispositivo
                responsable_p=request.form.get("responsable_p"),
                marca_p=request.form.get("marca_p"),
                modelo_p=request.form.get("modelo_p"),
                numserie_p=request.form.get("numserie_p"),
                cuentas_tiktok_p=request.form.get("cuentas_tiktok_p"),
                apple_id_p=request.form.get("apple_id_p"),


                vpn_p=request.form.get("vpn_p"),
                canal_vpn_p=request.form.get("canal_vpn_p"),
                room_p=request.form.get("room_p"),
                pais_p=request.form.get("pais_p"),
                costo_p=parse_float(request.form.get("costo_p")),
                comentarios_p=request.form.get("comentarios_p"),

                # Producto de venta
                marca_venta_p=request.form.get("marca_venta_p"),
                descripcion_venta_p=request.form.get("descripcion_venta_p"),
                caducidad_venta_p=parse_date(request.form.get("caducidad_venta_p")),
                costo_venta_p=parse_float(request.form.get("costo_venta_p")),
                lote_venta_p=request.form.get("lote_venta_p"),

                # Material general
                nombre_material_p=request.form.get("nombre_material_p"),
                tipo_material_p=request.form.get("tipo_material_p"),
                modelo_material_p=request.form.get("modelo_material_p"),
                responsable_material_p=request.form.get("responsable_material_p"),
                room_material_p=request.form.get("room_material_p"),
                precio_material_p=parse_float(request.form.get("precio_material_p"))
            )
            db.session.add(plantilla)

        db.session.commit()
        flash("✅ Plantilla guardada correctamente", "success")
        return redirect(url_for("listar_plantillas"))

    return render_template("nueva_plantilla.html", plantilla=plantilla)



@app.route("/plantillas/eliminar/<int:id>", methods=["POST"])
def eliminar_plantilla(id):
    plantilla = Plantilla.query.get_or_404(id)
    db.session.delete(plantilla)
    db.session.commit()
    return redirect(url_for("listar_plantillas"))



# Obtener una plantilla en formato JSON
@app.route("/plantilla/<int:plantilla_id>")
def obtener_plantilla(plantilla_id):
    plantilla = Plantilla.query.get_or_404(plantilla_id)
    return jsonify({
        "success": True,
        "id": plantilla.id,
        "nombre_p": plantilla.nombre_p,
        "tipo_p": plantilla.tipo_p,

        # Dispositivo
        "responsable_p": plantilla.responsable_p,
        "marca_p": plantilla.marca_p,
        "modelo_p": plantilla.modelo_p,
        "numserie_p": plantilla.numserie_p,
        "cuentas_tiktok_p": plantilla.cuentas_tiktok_p,
        "apple_id_p": plantilla.apple_id_p,

        "vpn_p": plantilla.vpn_p,
        "canal_vpn_p": plantilla.canal_vpn_p,
        "room_p": plantilla.room_p,
        "pais_p": plantilla.pais_p,
        "costo_p": plantilla.costo_p,
        "comentarios_p": plantilla.comentarios_p,

        # Producto venta
        "marca_venta_p": plantilla.marca_venta_p,
        "descripcion_venta_p": plantilla.descripcion_venta_p,
        "caducidad_venta_p": (
            plantilla.caducidad_venta_p.isoformat() if plantilla.caducidad_venta_p else None
        ),
        "costo_venta_p": plantilla.costo_venta_p,
        "lote_venta_p": plantilla.lote_venta_p,

        # Material general
        "nombre_material_p": plantilla.nombre_material_p,
        "tipo_material_p": plantilla.tipo_material_p,
        "modelo_material_p": plantilla.modelo_material_p,
        "responsable_material_p": plantilla.responsable_material_p,
        "room_material_p": plantilla.room_material_p,
        "precio_material_p": plantilla.precio_material_p,
    })
@app.route("/plantillas/por_tipo/<tipo>")
def plantillas_por_tipo(tipo):
    plantillas = Plantilla.query.filter_by(tipo_p=tipo).all()
    return jsonify({
        "success": True,
        "plantillas": [
            {"id": p.id, "nombre_p": p.nombre_p}
            for p in plantillas
        ]
    })



@app.route('/buscar_producto', methods=['GET', 'POST'])
def buscar_producto():
    if request.method == 'POST':
        codigo_barras = request.form['codigo_barras']
        producto = Dispositivo.query.filter_by(codigo_barras=codigo_barras).first()
        tipo = 'dispositivo'
        if not producto:
            producto = ProductoVenta.query.filter_by(codigo_barras=codigo_barras).first()
            tipo = 'producto_venta'
        if not producto:
            producto = MaterialGeneral.query.filter_by(codigo_barras=codigo_barras).first()
            tipo = 'material_general'

        if not producto:
            return render_template('resultado_busqueda.html', error="Producto no encontrado")

        grupos = Grupo.query.all()
        return render_template('resultado_busqueda.html',
                               producto=producto,
                               tipo=tipo,
                               codigo_barras=codigo_barras,
                               grupos=grupos)

    # Si es GET, solo mostramos el formulario de búsqueda
    return render_template('buscar_producto.html')

@app.route('/editar_producto/<tipo>/<int:id>', methods=['POST'])
def editar_producto(tipo, id):
    if tipo == 'dispositivo':
        producto = Dispositivo.query.get(id)
    elif tipo == 'producto_venta':
        producto = ProductoVenta.query.get(id)
    else:
        producto = MaterialGeneral.query.get(id)

    if not producto:
        flash("Producto no encontrado", "error")
        return redirect(url_for("buscar_producto"))

    # Actualizar atributos
    for key, value in request.form.items():
        if hasattr(producto, key):
            setattr(producto, key, value)

    db.session.commit()
    flash("Producto actualizado correctamente ✅", "success")
    return redirect(url_for("buscar_producto"))

@app.route('/eliminar_producto/<tipo>/<int:id>', methods=['POST'])
def eliminar_producto(tipo, id):
    if tipo == 'dispositivo':
        producto = Dispositivo.query.get(id)
    elif tipo == 'producto_venta':
        producto = ProductoVenta.query.get(id)
    else:
        producto = MaterialGeneral.query.get(id)

    if not producto:
        flash("Producto no encontrado", "error")
        return redirect(url_for("buscar_producto"))

    db.session.delete(producto)
    db.session.commit()
    flash("Producto eliminado correctamente 🗑️", "success")
    return redirect(url_for("buscar_producto"))

def to_dict(obj):
    """Convierte un objeto SQLAlchemy en dict y reemplaza grupo_id por grupo.nombre"""
    data = {c.name: getattr(obj, c.name) for c in obj.__table__.columns}

    # Si existe relación con Grupo, reemplazar grupo_id con nombre
    if hasattr(obj, "grupo") and obj.grupo:
        data["grupo"] = obj.grupo.nombre
        data.pop("grupo_id", None)  # quitar el id para no duplicar

    return data



@app.route('/exportar_excel')
def exportar_excel():
    grupo = request.args.get('grupo', 'todos')
    tipo = request.args.get('tipo', 'todos')
    datos = {}

    if tipo in ['todos', 'dispositivos']:
        q = Dispositivo.query
        if grupo != 'todos':
            gid = Grupo.query.filter_by(nombre=grupo).first().id
            q = q.filter_by(grupo_id=gid)
        dispositivos = pd.DataFrame([to_dict(d) for d in q.all()])
        datos['Dispositivos'] = dispositivos

    if tipo in ['todos', 'productos_venta']:
        q = ProductoVenta.query
        if grupo != 'todos':
            gid = Grupo.query.filter_by(nombre=grupo).first().id
            q = q.filter_by(grupo_id=gid)
        productos = pd.DataFrame([to_dict(p) for p in q.all()])
        datos['Productos de Venta'] = productos

    if tipo in ['todos', 'material_general']:
        q = MaterialGeneral.query
        if grupo != 'todos':
            gid = Grupo.query.filter_by(nombre=grupo).first().id
            q = q.filter_by(grupo_id=gid)
        materiales = pd.DataFrame([to_dict(m) for m in q.all()])
        datos['Material General'] = materiales

    # Crear archivo Excel
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="xlsxwriter") as writer:
        for nombre, df in datos.items():
            df.to_excel(writer, sheet_name=nombre, index=False)
    output.seek(0)

    filename = f"inventario_{grupo}.xlsx" if grupo != "todos" else "inventario_completo.xlsx"
    return send_file(output, download_name=filename, as_attachment=True)



@app.route('/agregar_grupo', methods=['GET', 'POST'])
def agregar_grupo():
    if request.method == 'POST':
        nombre = request.form.get('nombre')
        descripcion = request.form.get('descripcion', '')

        if not nombre:
            flash("El nombre del grupo es obligatorio", "error")
            return redirect(url_for('agregar_grupo'))

        # Validar que no exista otro grupo con el mismo nombre
        existente = Grupo.query.filter_by(nombre=nombre).first()
        if existente:
            flash("Ya existe un grupo con ese nombre", "error")
            return redirect(url_for('agregar_grupo'))

        nuevo = Grupo(nombre=nombre, descripcion=descripcion)
        db.session.add(nuevo)
        db.session.commit()
        print("DEBUG:", request.form.to_dict())

        flash("Grupo agregado correctamente ✅", "success")
        return redirect(url_for('inventario_general'))
    print("DEBUG:", request.form.to_dict())

    return render_template('agregar_grupo.html')

@app.route('/eliminar_grupo/<int:grupo_id>', methods=['POST'])
def eliminar_grupo(grupo_id):
    grupo = db.session.get(Grupo, grupo_id)  # forma moderna en SQLAlchemy 2.0

    if not grupo:
        print(f"[DEBUG] Grupo con ID {grupo_id} no encontrado.")
        flash("El grupo no existe ❌", "error")
        return redirect(url_for('inventario_general'))

    # Evitar eliminar si tiene artículos
    tiene_articulos = (
        Dispositivo.query.filter_by(grupo_id=grupo.id).first() or
        ProductoVenta.query.filter_by(grupo_id=grupo.id).first() or
        MaterialGeneral.query.filter_by(grupo_id=grupo.id).first()
    )
    if tiene_articulos:
        print(f"[DEBUG] Grupo {grupo.nombre} tiene artículos asociados, no se elimina.")
        flash("No se puede eliminar un grupo que tiene artículos asociados", "error")
        return redirect(url_for('inventario_general'))

    try:
        db.session.delete(grupo)
        db.session.commit()
        print(f"[DEBUG] Grupo eliminado: {grupo.nombre} (ID={grupo_id})")
        flash(f"Grupo '{grupo.nombre}' eliminado correctamente 🗑️", "success")
    except Exception as e:
        db.session.rollback()
        print(f"[ERROR] No se pudo eliminar el grupo: {e}")
        flash("Error al eliminar el grupo", "error")

    return redirect(url_for('inventario_general'))


@app.route("/lista_vpn")
def lista_vpn():
    # Traer todos los dispositivos con sus campos clave
    dispositivos = Dispositivo.query.with_entities(
        Dispositivo.vpn,
        Dispositivo.canal_vpn,
        Dispositivo.modelo,
        Dispositivo.responsable,
        Dispositivo.room
    ).all()

    # Agrupar por tipo de VPN
    vpn_dict = {}
    for d in dispositivos:
        vpn_name = d.vpn or "Sin VPN"
        if vpn_name not in vpn_dict:
            vpn_dict[vpn_name] = []
        vpn_dict[vpn_name].append(d)

    return render_template("lista_vpn.html", vpn_dict=vpn_dict)





#logs-------
import logging
from logging.handlers import RotatingFileHandler

# 📂 Ruta absoluta para que no falle con NSSM
LOG_DIR = os.path.join("C:\\appinventario", "logs")
LOG_FILE = os.path.join(LOG_DIR, "app.log")

# Crear carpeta logs si no existe
if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)

# Configurar el handler de logs con rotación
file_handler = RotatingFileHandler(LOG_FILE, maxBytes=10240, backupCount=5)
file_handler.setFormatter(logging.Formatter(
    "%(asctime)s [%(levelname)s] %(message)s in %(pathname)s:%(lineno)d"
))
file_handler.setLevel(logging.INFO)

# Agregar el handler al logger de Flask
if not app.logger.handlers:
    app.logger.addHandler(file_handler)

app.logger.setLevel(logging.INFO)

# 🔹 Mensaje inicial (para forzar creación de app.log)
app.logger.info("✅ Servidor Flask iniciado correctamente y logging configurado.")

#---------------------







# =======================
# Bootstrap de tablas y grupos por defecto
# =======================
with app.app_context():
    db.create_all()

    grupos_defecto = [
        ('EC', 'Grupo EC'),
        ('GL', 'Grupo GL'),
        ('RH', 'Grupo RH'),
        ('PCG', 'Grupo PCG'),
        ('ALMACEN', 'Grupo ALMACEN')
    ]

    for nombre, descripcion in grupos_defecto:
        if not Grupo.query.filter_by(nombre=nombre).first():
            g = Grupo(nombre=nombre, descripcion=descripcion)
            db.session.add(g)
    db.session.commit()


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
