document.addEventListener("DOMContentLoaded", () => {
    const tipoSelect = document.getElementById("tipo");
    const dispositivoFields = document.getElementById("dispositivoFields");
    const productoVentaFields = document.getElementById("productoVentaFields");
    const materialGeneralFields = document.getElementById("materialGeneralFields");

    const plantillaSelect = document.getElementById("plantilla");
    const buscarInput = document.getElementById("buscarPlantilla");
    const resultMessage = document.getElementById("resultMessage");

    let todasLasPlantillas = [];

    // Mostrar/ocultar campos según tipo
    if (tipoSelect) {
        tipoSelect.addEventListener("change", async () => {
            dispositivoFields.style.display = "none";
            productoVentaFields.style.display = "none";
            materialGeneralFields.style.display = "none";

            if (tipoSelect.value === "dispositivo") {
                dispositivoFields.style.display = "block";
            } else if (tipoSelect.value === "producto_venta") {
                productoVentaFields.style.display = "block";
            } else if (tipoSelect.value === "material_general") {
                materialGeneralFields.style.display = "block";
            }

            // Cuando cambie tipo, cargar plantillas de ese tipo
            if (plantillaSelect) {
                await cargarPlantillasPorTipo(tipoSelect.value);
            }
        });
    }

    // Buscar dentro de las plantillas por nombre
    if (buscarInput && plantillaSelect) {
        buscarInput.addEventListener("input", () => {
            const filtro = buscarInput.value.toLowerCase();
            plantillaSelect.innerHTML = `<option value="">-- Selecciona una plantilla --</option>`;

            todasLasPlantillas
                .filter(p => p.nombre_p.toLowerCase().includes(filtro))
                .forEach(p => {
                    const opt = document.createElement("option");
                    opt.value = p.id;
                    opt.textContent = p.nombre_p;
                    plantillaSelect.appendChild(opt);
                });
        });
    }

    // Cargar datos de plantilla seleccionada
    if (plantillaSelect) {
        plantillaSelect.addEventListener("change", async () => {
            const id = plantillaSelect.value;
            if (!id) return;

            try {
                const res = await fetch(`/plantilla/${id}`);
                const data = await res.json();

                if (data.success) {
                    // Autollenado de campos
                    if (data.tipo_p === "dispositivo") {
                        document.querySelector("input[name='responsable']").value = data.responsable_p || "";
                        document.querySelector("input[name='marca']").value = data.marca_p || "";
                        document.querySelector("input[name='modelo']").value = data.modelo_p || "";
                        document.querySelector("input[name='numserie']").value = data.numserie_p || "";
                        document.querySelector("input[name='vpn']").value = data.vpn_p || "";
                        document.querySelector("input[name='canal_vpn']").value = data.canal_vpn_p || "";
                        document.querySelector("input[name='room']").value = data.room_p || "";
                        document.querySelector("input[name='cuentas_tiktok_p']").value = data.cuentas_tiktok_p || "";
                        document.querySelector("input[name='pais']").value = data.pais_p || "";
                        document.querySelector("input[name='apple_id_p']").value = data.apple_id_p || "";
                        document.querySelector("input[name='costo']").value = data.costo_p || "";
                        document.querySelector("textarea[name='comentarios']").value = data.comentarios_p || "";
                    }
                    else if (data.tipo_p === "producto_venta") {
                        document.querySelector("input[name='marca_venta']").value = data.marca_venta_p || "";
                        document.querySelector("input[name='descripcion_venta']").value = data.descripcion_venta_p || "";
                        document.querySelector("input[name='caducidad_venta']").value = data.caducidad_venta_p || "";
                        document.querySelector("input[name='costo_venta']").value = data.costo_venta_p || "";
                        document.querySelector("input[name='lote_venta']").value = data.lote_venta_p || "";
                    }
                    else if (data.tipo_p === "material_general") {
                        document.querySelector("input[name='nombre_material']").value = data.nombre_material_p || "";
                        document.querySelector("input[name='tipo_material']").value = data.tipo_material_p || "";
                        document.querySelector("input[name='modelo_material']").value = data.modelo_material_p || "";
                        document.querySelector("input[name='responsable_material']").value = data.responsable_material_p || "";
                        document.querySelector("input[name='room_material']").value = data.room_material_p || "";
                        document.querySelector("input[name='precio_material']").value = data.precio_material_p || "";
                    }
                }
            } catch (err) {
                console.error("Error cargando plantilla:", err);
            }
        });
    }

    // -------- FUNCIONES --------
    async function cargarPlantillasPorTipo(tipo) {
        plantillaSelect.innerHTML = `<option value="">-- Selecciona una plantilla --</option>`;
        todasLasPlantillas = [];

        if (!tipo) return;

        try {
            const res = await fetch(`/plantillas/por_tipo/${tipo}`);
            const data = await res.json();

            if (data.success && data.plantillas.length > 0) {
                todasLasPlantillas = data.plantillas;

                data.plantillas.forEach(p => {
                    const opt = document.createElement("option");
                    opt.value = p.id;
                    opt.textContent = p.nombre_p;
                    plantillaSelect.appendChild(opt);
                });
            } else {
                const opt = document.createElement("option");
                opt.value = "";
                opt.textContent = "⚠️ No hay plantillas de este tipo";
                plantillaSelect.appendChild(opt);
            }
        } catch (err) {
            console.error("Error cargando lista de plantillas:", err);
        }
    }


});
