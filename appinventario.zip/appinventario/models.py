from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

# ======================
# Modelo de Grupos
# ======================
class Grupo(db.Model):
    __tablename__ = "grupos"
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(50), unique=True, nullable=False)
    descripcion = db.Column(db.String(200))

    # Relaciones
    dispositivos = db.relationship("Dispositivo", backref="grupo", lazy=True)
    productos = db.relationship("ProductoVenta", backref="grupo", lazy=True)
    materiales = db.relationship("MaterialGeneral", backref="grupo", lazy=True)

    def __repr__(self):
        return f"<Grupo {self.nombre}>"


# ======================
# Códigos de Barras
# ======================
class CodigoBarra(db.Model):
    __tablename__ = "codigos_barras"
    codigo = db.Column(db.String(50), primary_key=True)

    def __repr__(self):
        return f"<CodigoBarra {self.codigo}>"


# ======================
# Dispositivos
# ======================
class Dispositivo(db.Model):
    __tablename__ = "dispositivos"
    id = db.Column(db.Integer, primary_key=True)
    grupo_id = db.Column(db.Integer, db.ForeignKey("grupos.id"), nullable=False)

    responsable = db.Column(db.String(100), nullable=False)
    marca = db.Column(db.String(100), nullable=False)
    modelo = db.Column(db.String(100), nullable=False)
    numserie = db.Column(db.String(100), nullable=False)

    vpn = db.Column(db.String(50), nullable=False)
    canal_vpn = db.Column(db.String(100))

    room = db.Column(db.String(50), nullable=False)
    cuentas_tiktok = db.Column(db.String(200))
    pais = db.Column(db.String(50), nullable=False)
    apple_id = db.Column(db.String(100))

    foto = db.Column(db.String(200))
    costo = db.Column(db.Float, nullable=False)
    fecha_agregacion = db.Column(db.Date, default=datetime.utcnow)
    comentarios = db.Column(db.Text)

    codigo_barras = db.Column(db.String(50), unique=True, nullable=False)

    def __repr__(self):
        return f"<Dispositivo {self.marca} {self.modelo}>"


# ======================
# Productos de Venta
# ======================
class ProductoVenta(db.Model):
    __tablename__ = "productos_venta"
    id = db.Column(db.Integer, primary_key=True)
    grupo_id = db.Column(db.Integer, db.ForeignKey("grupos.id"), nullable=False)

    marca = db.Column(db.String(100), nullable=False)
    descripcion = db.Column(db.String(200), nullable=False)
    caducidad = db.Column(db.Date)
    fecha_agregacion = db.Column(db.Date, default=datetime.utcnow)

    costo = db.Column(db.Float, nullable=False)
    lote = db.Column(db.String(100))
    codigo_barras = db.Column(db.String(50), unique=True, nullable=False)

    def __repr__(self):
        return f"<ProductoVenta {self.marca} - {self.descripcion}>"


# ======================
# Material General
# ======================
class MaterialGeneral(db.Model):
    __tablename__ = "material_general"
    id = db.Column(db.Integer, primary_key=True)

    nombre = db.Column(db.String(100), nullable=False)
    tipo = db.Column(db.String(100), nullable=False)
    modelo = db.Column(db.String(100))
    responsable = db.Column(db.String(100))

    grupo_id = db.Column(db.Integer, db.ForeignKey("grupos.id"), nullable=False)
    room = db.Column(db.String(50))

    fecha_agregacion = db.Column(db.Date, default=datetime.utcnow)
    precio = db.Column(db.Float, nullable=False)
    codigo_barras = db.Column(db.String(50), unique=True, nullable=False)

    def __repr__(self):
        return f"<MaterialGeneral {self.nombre} ({self.tipo})>"


# ======================
# Plantillas
# ======================
class Plantilla(db.Model):
    __tablename__ = "plantillas"
    id = db.Column(db.Integer, primary_key=True)

    # Campos generales
    nombre_p = db.Column(db.String(100), nullable=False)   # Ejemplo: iPhone 13 estándar
    tipo_p = db.Column(db.String(50), nullable=False)      # dispositivo / producto_venta / material_general
    fecha_creacion_p = db.Column(db.DateTime, default=datetime.utcnow)

    # -------- Campos Dispositivo --------
    responsable_p = db.Column(db.String(100))
    marca_p = db.Column(db.String(100))
    modelo_p = db.Column(db.String(100))
    numserie_p = db.Column(db.String(100))
    vpn_p = db.Column(db.String(100))
    canal_vpn_p = db.Column(db.String(100))
    room_p = db.Column(db.String(50))
    cuentas_tiktok_p = db.Column(db.String(200))
    pais_p = db.Column(db.String(100))
    apple_id_p = db.Column(db.String(100))
    costo_p = db.Column(db.Float)
    comentarios_p = db.Column(db.Text)

    # -------- Campos Producto de Venta --------
    marca_venta_p = db.Column(db.String(100))
    descripcion_venta_p = db.Column(db.String(200))
    caducidad_venta_p = db.Column(db.Date)
    costo_venta_p = db.Column(db.Float)
    lote_venta_p = db.Column(db.String(100))

    # -------- Campos Material General --------
    nombre_material_p = db.Column(db.String(100))
    tipo_material_p = db.Column(db.String(100))
    modelo_material_p = db.Column(db.String(100))
    responsable_material_p = db.Column(db.String(100))
    room_material_p = db.Column(db.String(50))
    precio_material_p = db.Column(db.Float)

    def __repr__(self):
        return f"<Plantilla {self.nombre_p} ({self.tipo_p})>"